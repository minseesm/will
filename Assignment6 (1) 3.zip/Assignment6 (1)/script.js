/*
* Title: Whale Fun
* Program Summary: Whale Fun enables the user to type in some human text, and have it spoken/displayed on the screen to them. Animations add to the fun of the program.
* Key Program Elements Utilized: querySelector, addEventListener, arrays, loops, nested loops, .push(), .join(), callback function, target.value, SpeechSynthesisUtterance(), window.speechSynthesis.speak();
    
    
    
    
    
            Arrays, Loops, parseInt, setTimeout(), location.href, document.location.reload(), Switch Staements, Return, charAt, .getDay(), Variables, use of document.getElementById with a variety of attributes (ex. the .value, .style.display, .style.width, etc.), a variety of Data Types, If ... Else If ... Else statements, Functions, Arithmetic Operators. HTML/CSS syntax utilized includes a HTML to PDF conversion, a detailed sitemap, a table, a feedback form, a menu, social media icons, and contact buttons.
    */




    function inputtovowels(inputted) {
      document.getElementById('originalPhrase').disabled = false;
      let resultarray = [];
      let input = inputted;
      let vowels = ['a', 'e', 'i', ' o', 'u'];
      let result;


      for (i = 0; i < input.length; i++) {

        for (j = 0; j < vowels.length; j++) {

          if (input[i] === vowels[j]) { // this is saying if each character of i includes each character of 2nd array - j

            if (input[i] === "e") {
              resultarray.push('ee');

            } else if (input[i] === "u") {
              resultarray.push('uu');

            } else {
              resultarray.push(input[i]);
            }
          }
        }
      }
      result = resultarray.join("").toUpperCase();
      return result;
    }









    document.querySelector("textarea").addEventListener("input", events => { // Is run every time value is changed.
      let getvalue = events.target.value.toLowerCase();
      if (inputtovowels(getvalue) === '') {
        document.getElementById('whaletalk').innerText = 'There are no vowels in your text, yet. Keep typing, and include some vowels!';
      }

      else {
        document.getElementById('whaletalk').innerText = inputtovowels(getvalue);
      }

    });



    document.getElementById('speakbtn').addEventListener("click", () => { // !!!!parameter is made blank. might have to put 'event'

      // freeze the input box (disable it), disable the button using the while it runs, and then stopped running - allow for new input and button again.


      let synth = window.speechSynthesis;
      let msg = new SpeechSynthesisUtterance("Your whale text is as follows:         " + document.getElementById('whaletalk').innerText.toLowerCase());
     

     synth.speak(msg);
  
            msg.addEventListener('start', function () {
          
                    
                  if (synth.speaking) {
          
              document.getElementById('originalPhrase').disabled = true;
          
                  }
                 
            });
              
                                 
          msg.addEventListener("end", (event) => {
          
          document.getElementById('originalPhrase').disabled = false;
          
          
          
            
          });


      
                       
                      
      
    });





function whalefacts () {
  let whale = []
}


// Slider part
var idx = 0;

var whaleImages = [
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2019-04/humpback-whale.jpg?h=d0b527cd&itok=S_rQ-6bY",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2018-08/Large_WW1113667%20%281%29_0.jpg?h=3e43625b&itok=o7_fPmFk",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/sperm_whale.jpg?h=f7d9296c&itok=e7dLG249",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/humpback_whales.jpg?h=82f92a78&itok=ue-c-6-I",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/blue_whale.jpg?h=44b879e5&itok=oxnwlQkH",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/humpback_whale.jpg?h=27f45369&itok=sW3z08l_",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2019-04/A-pod-of-male-narwhals.jpg?h=82f92a78&itok=_ZbsxNPF",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2019-04/narwhal-swimming-together.jpg?h=e5aec6c8&itok=X4CNRgZy",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/pygmy_blue_whale.jpg?h=82f92a78&itok=k6onZ5T7",
  "https://www.wwf.org.uk/sites/default/files/styles/gallery_image/public/2020-02/killer_whales.jpg?h=82f92a78&itok=K50b9S7J"
];

var copyRights = [
  "© John Van Den Hende",
  "© Jeff Duerr",
  "© Brian J. Skerry / National Geographic Stock / WWF",
  "© Tim Irvin / WWF-Canada",
  "© Richard Barrett / WWF-UK",
  "© William W. Rossiter / WWF",
  "© Paul Nicklen/National Geographic Stock / WWF-Canada",
  "© Paul Nicklen / National Geographic Creative / WWF-Canada",
  "© naturepl.com / Franco Banfi / WWF",
  "© National Geographic Creative / Ralph Lee Hopkins / WWF"

]

var whaleTitles = [
  "1. WHALES ARE DIVIDED INTO TWO MAIN GROUPS",
  "2. HUMPBACK WHALES DON’T EAT FOR MOST OF THE YEAR",
  "3. ALL TOOTHED WHALES HAVE A ‘MELON’ IN THEIR FOREHEADS",
  "4. SOME WHALES BUBBLE NET FEED",
  "5. THERE USED TO BE THOUSANDS OF BLUE WHALES",
  "6. WHALES ARE OFTEN CAUGHT IN NETS",
  "7. USUALLY ONLY MALE NARWHALS HAVE A TUSK - THAT DEVELOPS FROM A TOOTH",
  "8. THE NAME 'NARWHAL' COMES FROM OLD NORSE",
  "9. THE ANTARCTIC BLUE WHALE IS THE LARGEST ANIMAL ON THE PLANET",
  "10. KILLER WHALES ARE ACTUALLY DOLPHINS"
];

var whaleTexts = [
  "There are two types of whales: the baleen whales and the toothed whales. Baleen whales, including humpbacks and blue whales, have fibrous 'baleen' plates in their mouths instead of teeth, which help them filter out and consume huge quantities of krill, plankton, and crustaceans. Whereas toothed whales, such as orcas, beluga and sperm whales, have teeth which enable them to feed on larger prey such as fish and squid. <br><br> All dolphin families, including porpoises, are also classified as whales, as they are more related to their toothed counterparts.",
  "Humpback whales in the Southern Hemisphere live off their fat reserves for 5.5-7.5 months each year, as they migrate from their tropical breeding grounds to the Antarctic, to feed on krill.​",
  "It’s a mass of tissue which focuses the whales’ calls, vital for communication and echolocation.​ Like bats, they use this echolocation to \"see\".",
  "This involves whales cooperatively blowing bubbles that encircle their prey. As the prey won't cross through the bubbles, they're trapped, making it easy for the whales to eat them.​",
  "It's estimated that there were over 225,000 Antarctic blue whales before their exploitation in the 1900s. Today, blue whales are listed as endangered species, with less than 3,000 remaining in the wild.",
  "Over 80% of North Atlantic right whales have been entangled in fishing gear at least once during their lifetime - they often get caught many times in their lives.",
  "Used for foraging, displays of dominance and possibly fighting and breaking ice, the tusk is  also  a sensory tool used to detect changes in the sea around them.",
  "It means \"corpse whale\" as their skin colour resembles that of a drowned sailor.",
  "The Antarctic blue whale is the biggest of all blue whales. It is also the largest animal on the planet, weighing up to 200 tons (approximately 33 elephants) and reaching up to 30 metres in length. They can consume about 3,600kg of krill a day!",
  "Orcas, also known as \"killer whales\", are the largest members of the dolphin family. They are the ocean's top predators, preying on a diverse range of marine species, which include many fish species, penguins, seabirds, sea turtles, cephalopods and marine mammals such as seals and even whales."
]

const sliderImage = document.getElementById("sliderImage");
const sliderTitle = document.getElementById("sliderTextTitle");
const sliderText = document.getElementById("sliderText");
const copyright = document.getElementById("copyright-image");
const slider = document.getElementById("slider");



// fadein/out

function unfade(element) {
  var op = 0.1;  // initial opacity
  var timer = setInterval(function () {
      if (op >= 1){
          clearInterval(timer);
      }
      element.style.opacity = op;
      element.style.filter = 'alpha(opacity=' + op * 100 + ")";
      op += op * 0.1;
  }, 10);
  element.style.display = 'block';
  sliderImage.src = whaleImages[idx];
  sliderTitle.innerText = whaleTitles[idx];
  sliderText.innerText = whaleTexts[idx];
  copyright.innerText = copyRights[idx];
}
function fade(slider) {
  var op = 1;  // initial opacity
  var timer = setInterval(function () {
      if (op <= 0.1){
          clearInterval(timer);
          element.style.display = 'none';
      }
      element.style.opacity = op;
      element.style.filter = 'alpha(opacity=' + op * 100 + ")";
      op -= op * 0.1;
  }, 10);
}
function changeSlider() {
  
  console.log(idx);
  console.log("done");
  unfade(slider);

  fade(slider)
}

let loopInterval = setInterval(() => {
  
  idx++;
  
  if (idx === 10) {
    idx = 0;
  }

  changeSlider();

}, 10000);






// SpeechSynthesis.speaking Read only A boolean value that returns true if an utterance is currently in the process of being spoken — even if SpeechSynthesis is in a paused state.
// so while speech synthesis is speaking, then we disable the input box......








// objects, while (do while?)


// Idea: Every time sound button is pressed, we give them a didyou know whale fact which comes from an object's key value pairs.
// Sound button - when its clicked its a loop - every time its clicked the variable is set to 1, and if its clicked while the variable is set to 1 it wont start over and run.

// loop - every 10 seconds, keep running until all facts are exhausted and completed -> pick a fact from an object!!!! so we use objects.
// event listenersafter functions







// we take the text from javascript, put it to text to speech api and make it talk in whale talk on the website for all viewers.
// for loop we say for each time we say e  or u we go where the character is at and we replace
// we double the e and u appearance, no vowels to constants, we capitalize, use arrays and loops to iterate through all of the text
//translate to sanother lasnguage
//check for certain words
//perrson can try to see what the result is, and guess, then we show them the write and wrong letters and the correct rsult and give them an accuracy score
//whale facts on site
//dolphin or fish checker, whale vs beluga whale, fish, dog, cat translator
// avg life expectency ... give them facts at each step of the process ...they have to guess the result correctly to morve on the stepgive them more facts (up to 3) until they lost like 3 times

//.toUppercase()
//vowel check 
//https://developer.twitter.com/en/docs/twitter-for-websites/tweet-button/overview



// SpeechSynthesis.speaking Read only A boolean value that returns true if an utterance is currently in the process of being spoken — even if SpeechSynthesis is in a paused state.
// so while speech synthesis is speaking, then we disable the input box......








// objects, while (do while?)


// Idea: Every time sound button is pressed, we give them a didyou know whale fact which comes from an object's key value pairs.
// Sound button - when its clicked its a loop - every time its clicked the variable is set to 1, and if its clicked while the variable is set to 1 it wont start over and run.

// loop - every 10 seconds, keep running until all facts are exhausted and completed -> pick a fact from an object!!!! so we use objects.
// event listenersafter functions







// we take the text from javascript, put it to text to speech api and make it talk in whale talk on the website for all viewers.
// for loop we say for each time we say e  or u we go where the character is at and we replace
// we double the e and u appearance, no vowels to constants, we capitalize, use arrays and loops to iterate through all of the text
//translate to sanother lasnguage
//check for certain words
//perrson can try to see what the result is, and guess, then we show them the write and wrong letters and the correct rsult and give them an accuracy score
//whale facts on site
//dolphin or fish checker, whale vs beluga whale, fish, dog, cat translator
// avg life expectency ... give them facts at each step of the process ...they have to guess the result correctly to morve on the stepgive them more facts (up to 3) until they lost like 3 times

//.toUppercase()
//vowel check 
//https://developer.twitter.com/en/docs/twitter-for-websites/tweet-button/overview