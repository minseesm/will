let input = "Qwer123!23" 
let strong = 0; 
let userID = []
let userPW = []

function isUppercase(input) {
  if (typeof input === "string") {
    if (input === input.toUpperCase() && input !== input.toLowerCase()) {
      
      return true;
    }
  } else {
    return false;
}
}

function hasUppercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isUppercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}

function isLowercase(input) {
  if (typeof input === "string") {
    if (input !== input.toUpperCase() && input === input.toLowerCase()) {

      return true;
    };
  } else {
    return false;
}
}

function hasLowercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isLowercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}


function isLongEnough(input) {
  if (input.length >= 8) {
    strong++;
    return true;
  } else {
    return false;
  }
}

function hasSpecialchar(input) {
  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(input)) {
    strong++
    return true;
  } else {
    return false; 
  }
}


function isPasswordValid(input) {
  
  let upper = hasUppercase(input);
  let lower = hasLowercase(input);
  let long = isLongEnough(input);
  let special = hasSpecialchar(input);
  

  if (upper && lower && long && special) {
    console.log("okay");
    return "Okay";
  } else {
    console.log("nope");
    return "nope";
  }

}

function duplicate() {
  const ID = document.getElementById('idSign').value;
  if (userID.includes(ID)) {
    document.getElementById("resultID").innerText = "There is a same ID";
    return '';
  }
  else {
    document.getElementById("resultID").innerText = "You can use this ID";
    return ID;
  }
}

function Valid() {
  const PW = document.getElementById('pwSign').value;
  document.getElementById("resultPW").innerText = isPasswordValid(PW);
}
// 등록 버튼시
function register() {
  const ID = document.getElementById('idSign').value;
  const PW = document.getElementById('pwSign').value;
  if ((duplicate() !== '') && (isPasswordValid(PW) === "Okay")) {
    saveUser(ID, PW);
    return "Sign up Successfully";
  }
  else {
    return "Error, Try agin";
  }
}

function saveUser(newID, newPW) {
  userID.push(newID);
  userPW.push(newPW);
}


function login() {
  const ID = document.getElementById('idLogin').value;
  const PW = document.getElementById('pwLogin').value;
  if (userID.includes(ID)) {
    if (PW === userPW[userID.indexOf(ID)]) {
      return "Login Successfully";
    }
    else { return "wrong password"; }
  }
  else {
    return "Check your ID";
  }
}

document.getElementById('signup').addEventListener("click", function() {
  const section = document.getElementById('signupSection').classList;
  section.toggle("hide");
})

document.getElementById('login').addEventListener("click", function() {
  const section = document.getElementById('loginSection').classList;
  section.toggle("hide");
})

document.getElementById("register").addEventListener("click", function(){
  let regi = register();
  document.getElementById('signupSection').classList.toggle('hide');
  document.getElementById("Status").innerText = regi;
  document.getElementById('idSign').value = '';
  document.getElementById('pwSign').value = '';
})

// Login btn
document.getElementById("loginbtn").addEventListener("click", function(){
  let loginstatus = login();
  document.getElementById("Status").innerText = loginstatus;
  document.getElementById('loginSection').classList.toggle('hide');
  document.getElementById('idLogin').value = '';
  document.getElementById('pwLogin').value = '';
})


// 아이디 받고
////////////////// 패스워드 받는데 체크
// 등록버튼시 어레이에 세이브

/// 로그인 버튼시
/// 아이디 패스워드 받고
/// 어레이에 있는지 확인 후 로그인 성공 / 실패