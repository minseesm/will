let input = "Qwer123!23" 
let strong = 0; 
let userID = []
let userPW = []
let userQ = []
let userA = []
let userIDidx = 0;

function isUppercase(input) {
  if (typeof input === "string") {
    if (input === input.toUpperCase() && input !== input.toLowerCase()) {
      
      return true;
    }
  } else {
    return false;
}
}

function hasUppercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isUppercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}

function isLowercase(input) {
  if (typeof input === "string") {
    if (input !== input.toUpperCase() && input === input.toLowerCase()) {

      return true;
    };
  } else {
    return false;
}
}

function hasLowercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isLowercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}


function isLongEnough(input) {
  if (input.length >= 8) {
    strong++;
    return true;
  } else {
    return false;
  }
}

function hasSpecialchar(input) {
  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(input)) {
    strong++
    return true;
  } else {
    return false; 
  }
}


function isPasswordValid(input) {
  
  let upper = hasUppercase(input);
  let lower = hasLowercase(input);
  let long = isLongEnough(input);
  let special = hasSpecialchar(input);
  

  if (upper && lower && long && special) {
    console.log("okay");
    return "Okay";
  } else {
    console.log("nope");
    return "nope";
  }

}

function duplicate() {
  const ID = document.getElementById('idSign').value;
  if (userID.includes(ID)) {
    document.getElementById("resultID").innerText = "There is a same ID";
    return '';
  }
  else {
    document.getElementById("resultID").innerText = "You can use this ID";
    return ID;
  }
}

function Valid(type) {
  if (type === "Sign") {
    const PW = document.getElementById('pwSign').value;
    document.getElementById("resultPW").innerText = isPasswordValid(PW);
    return PW;
  }
  else if (type === "Change") {
    const NPW = document.getElementById('newPW').value;
    document.getElementById("newResultPW").innerText = isPasswordValid(NPW);
    return NPW;
  }
}

function samePW(type) {
  if (type === "Sign"){
    let PW = Valid("Sign");
    const CPW = document.getElementById("pwSignC").value;

    if (PW === CPW) {
      document.getElementById("checkPW").innerText = "Same";
      return "Okay";
    }
    else {
      document.getElementById("checkPW").innerText = "Diffrent";
      return 'nope';
    }
  }
  else if (type === "Change") {
    let NPW = Valid("Change");
    let NCPW = document.getElementById("newPWC").value;
    if (NPW === NCPW) {
      document.getElementById("newCheckPW").innerText = "Same";
      return "Okay";
    }
    else {
      document.getElementById("newCheckPW").innerText = "Diffrent";
      return 'nope';
    }
  }
  
}

function isempty() {
  const answer = document.getElementById("answer").value;
  if (answer === '') {
    document.getElementById("answerEmpty").innerText = "Write answer";
    document.getElementById("answerEmpty").style.display = "block";
    return 'nope';
  }
  else {
    document.getElementById("answerEmpty").style.display = "none";
    return "Okay";
  }
}

// 등록 버튼시
function register() {
  const ID = document.getElementById('idSign').value;
  const PW = document.getElementById('pwSign').value;
  const Q = document.getElementById('question').value;
  const A = document.getElementById('answer').value;

  if ((duplicate() !== '') && (isPasswordValid(PW) === "Okay") && (samePW("Sign") === "Okay") && (isempty() === "Okay")) {
    saveUser(ID, PW, Q, A);
    return "Sign up Successfully";
  }
  else {
    return "Error, Try agin";
  }
}

function saveUser(newID, newPW, newQ, newA) {
  userID.push(newID);
  userPW.push(newPW);
  userQ.push(newQ);
  userA.push(newA);
}


function login() {
  const ID = document.getElementById('idLogin').value;
  const PW = document.getElementById('pwLogin').value;
  if (userID.includes(ID)) {
    if (PW === userPW[userID.indexOf(ID)]) {
      return "Login Successfully";
    }
    else { return "wrong password"; }
  }
  else {
    return "Check your ID";
  }
}

function QAValid() {
  const ID = document.getElementById('idForgot').value;
  const Q = document.getElementById('questionForgot').value;
  const A = document.getElementById('answerForgot').value;
  if (userID.includes(ID)) {
    if ((Q === userQ[userID.indexOf(ID)]) && (A === userA[userID.indexOf(ID)])) {
      userIDidx = userID.indexOf(ID);
      return "Okay";
    }
    else { return "wrong question or answer"; }
  }
  else {
    return "Check your ID and Q&A";
  }
}

document.getElementById('signup').addEventListener("click", function() {
  const section_signup = document.getElementById('signupSection').classList;
  const section_login = document.getElementById('loginSection').classList;
  section_signup.toggle("hide");
  if (!section_login.contains("hide")) {section_login.add("hide");}
})

document.getElementById('login').addEventListener("click", function() {
  const section_signup = document.getElementById('signupSection').classList;
  const section_login = document.getElementById('loginSection').classList;
  section_login.toggle("hide");
  if (!section_signup.contains("hide")) {section_signup.add("hide");}
})

document.getElementById('forgotbtn').addEventListener("click", function() {
  const section_forgot = document.getElementById('forgotSection').classList;
  const section_login = document.getElementById('loginSection').classList;
  section_forgot.toggle("hide");
  if (!section_login.contains("hide")) {section_login.add("hide");}
})

document.getElementById('okaybtn').addEventListener("click", function() {
  let forgotstatus = QAValid();
  if (forgotstatus === "Okay") {
    const section_forgot = document.getElementById('forgotSection').classList;
    const section_okay = document.getElementById('newPwSection').classList;
    section_okay.toggle("hide");
    if (!section_forgot.contains("hide")) {section_forgot.add("hide");}
    
    document.getElementById("Status").innerText = "Change your password as new one";
  }
  else {
    document.getElementById("Status").innerText = forgotstatus;
  }
})

document.getElementById('changebtn').addEventListener("click", function() {
  let changestatus = samePW("Change");
  if (changestatus === "Okay") {
    const section_change = document.getElementById('forgotSection').classList;
    const section_okay = document.getElementById('newPwSection').classList;
    section_okay.toggle("hide");
    if (!section_change.contains("hide")) {section_change.add("hide");}
    
    userPW[userIDidx] = document.getElementById("newPW").value;
    document.getElementById("Status").innerText = "Password Changed Successfully";
  }
})

document.getElementById("register").addEventListener("click", function(){
  let regi = register();
  document.getElementById('signupSection').classList.toggle('hide');
  document.getElementById("Status").innerText = regi;
  document.getElementById('idSign').value = '';
  document.getElementById('pwSign').value = '';
})

// Login btn
document.getElementById("loginbtn").addEventListener("click", function(){
  let loginstatus = login();
  document.getElementById("Status").innerText = loginstatus;
  document.getElementById('loginSection').classList.toggle('hide');
  document.getElementById('idLogin').value = '';
  document.getElementById('pwLogin').value = '';
})


// 아이디 받고
////////////////// 패스워드 받는데 체크
// 등록버튼시 어레이에 세이브

/// 로그인 버튼시
/// 아이디 패스워드 받고
/// 어레이에 있는지 확인 후 로그인 성공 / 실패