const menu = {

    _courses: {
      appetizer_list: [],
      main_list:  [],
      dessert_list: [], 
    },

    get get_appetizers() { 
        return this.appetizer_list},
    get get_mains() { 
        return this.main_list},
    get get_desserts() { 
        return this.dessert_list},
    get get_courses() { 
        return {
            appetizers: this._courses.appetizer_list,
            mains: this._courses.main_list,
            desserts: this._courses.dessert_list,
        } 
    },


    set set_appetizer(newAppetizer) { 
        this.appetizer_list = newAppetizer},
    set set_main(newMain) { 
        this.main_list = newMain},
    set set_desserts(newDessert) { 
        this.dessert_list = newDessert},
    
    addDishToCourse(course, newDish, newDishPrice) {
        const dish = {
            name: newDish,
            price: newDishPrice,
        };
        this._courses[course].push(dish);
    },
    
    getRandomDishFromCourse(course) {
        const dishes = this._courses[course];
        const randomDish = Math.floor(Math.random() * dishes.length);
        return dishes[randomDish];
    },

    generateRandomMeal(){
        const appetizer = this.getRandomDishFromCourse('appetizer_list');
        const main = this.getRandomDishFromCourse('main_list');
        const dessert = this.getRandomDishFromCourse('dessert_list');
        const totalPrice = appetizer.price + main.price + dessert.price;
        
        return `Your meal is ${appetizer.name}, ${main.name}, ${dessert.name} The price is $${totalPrice}.`;
    }

};


let meal = menu;

meal.addDishToCourse('appetizer_list', 'Facaccia', 7.95);
meal.addDishToCourse('appetizer_list', 'Misto Di Olive', 7.95);
meal.addDishToCourse('appetizer_list', 'Meatballs', 9.95);

meal.addDishToCourse('main_list', 'Salsiccia Pizza', 20.95);
meal.addDishToCourse('main_list', 'Spaghetti Bolognese', 20.95);
meal.addDishToCourse('main_list', 'Lasagna Veg', 18.95);

meal.addDishToCourse('dessert_list', 'Tiramisu', 10.95);
meal.addDishToCourse('dessert_list', 'Gelato', 6.95);
meal.addDishToCourse('dessert_list', 'Nutella Pizza', 11.95);

let randomMeal = meal.generateRandomMeal();
console.log('Meals]');
console.log(randomMeal);
