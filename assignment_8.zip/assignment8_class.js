class menu {

    _courses = {
      appetizer_list: [],
      main_list:  [],
      dessert_list: [], 
    }

    get get_appetizers() { 
        return this.appetizer_list}

    get get_mains() { 
        return this.main_list}

    get get_desserts() { 
        return this.dessert_list}

    get get_courses() { 
        return {
            appetizers: this._courses.appetizer_list,
            mains: this._courses.main_list,
            desserts: this._courses.dessert_list,
        } 
    }


    set set_appetizer(newAppetizer) { 
        this.appetizer_list = newAppetizer}

    set set_main(newMain) { 
        this.main_list = newMain}

    set set_desserts(newDessert) { 
        this.dessert_list = newDessert}
    
    addDishToCourse(course, newDish, newDishPrice) {
        const dish = {
            name: newDish,
            price: newDishPrice,
        };
        this._courses[course].push(dish);
    }
    
    getRandomDishFromCourse(course) {
        const dishes = this._courses[course];
        const randomDish = Math.floor(Math.random() * dishes.length);
        return dishes[randomDish];
    }

    generateRandomMeal(){
        const appetizer = this.getRandomDishFromCourse('appetizer_list');
        const main = this.getRandomDishFromCourse('main_list');
        const dessert = this.getRandomDishFromCourse('dessert_list');
        const totalPrice = appetizer.price + main.price + dessert.price;
        
        return `Your meal is ${appetizer.name}, ${main.name}, ${dessert.name} The price is $${totalPrice}.`;
    }

};


let italyMeal = new menu;

italyMeal.addDishToCourse('appetizer_list', 'Facaccia', 7.95);
italyMeal.addDishToCourse('appetizer_list', 'Misto Di Olive', 7.95);
italyMeal.addDishToCourse('appetizer_list', 'Meatballs', 9.95);

italyMeal.addDishToCourse('main_list', 'Salsiccia Pizza', 20.95);
italyMeal.addDishToCourse('main_list', 'Spaghetti Bolognese', 20.95);
italyMeal.addDishToCourse('main_list', 'Lasagna Veg', 18.95);

italyMeal.addDishToCourse('dessert_list', 'Tiramisu', 10.95);
italyMeal.addDishToCourse('dessert_list', 'Gelato', 6.95);
italyMeal.addDishToCourse('dessert_list', 'Nutella Pizza', 11.95);

let ChinessMeal = new menu;

ChinessMeal.addDishToCourse('appetizer_list', 'Deep-Fried Wonton', 11.95);
ChinessMeal.addDishToCourse('appetizer_list', 'Spring Roll', 3.75);
ChinessMeal.addDishToCourse('appetizer_list', 'Pot Sticker', 14.95);

ChinessMeal.addDishToCourse('main_list', 'Kung Pao Diced Chicken with Chili Peppers and Peanuts', 20.95);
ChinessMeal.addDishToCourse('main_list', 'Prawns in Curry Sauce', 25.50);
ChinessMeal.addDishToCourse('main_list', 'Ginger Beef',25.95);

ChinessMeal.addDishToCourse('dessert_list', 'Breaded Deep-Fried Banana', 13.95);
ChinessMeal.addDishToCourse('dessert_list', 'Breaded Deep-Fried Lychee in Sweet-and-Sour Sauce', 13.95);
ChinessMeal.addDishToCourse('dessert_list', 'Steam Rice Cake', 7.95);


let randomItalyMeal = italyMeal.generateRandomMeal();
let randomChinessMeal = ChinessMeal.generateRandomMeal();
console.log('[Italy Meals]');
console.log(randomItalyMeal);
console.log('[Chiness Meals]');
console.log(randomChinessMeal);
console.log(ChinessMeal);